"use client";
import { useState } from "react";
import { Layers, ArrowRight } from "lucide-react";
import { Project } from "@/data/portfolioData";

const TABS = [
  ["Overview", "Overview"],
  ["specs", "Microarchitecture & Specs"],
  ["strategy", "Verification / Implementation"],
  ["results", "Quantified Results"],
] as const;

interface ProjectCardProps {
  p: Project;
  onOpenCaseStudy?: (p: Project) => void;
}

export default function ProjectCard({ p, onOpenCaseStudy }: ProjectCardProps) {
  const [tab, setTab] = useState<string>("Overview");
  const [code, setCode] = useState(false);

  return (
    <article className="flex flex-col rounded-xl border border-edge bg-card p-5 sm:p-6 transition hover:border-slate-700 shadow-sm">
      <div className="flex items-center justify-between">
        <span className="font-mono text-xs font-semibold text-bus uppercase tracking-wide">{p.category}</span>
        {onOpenCaseStudy && (
          <button
            onClick={() => onOpenCaseStudy(p)}
            className="inline-flex items-center gap-1.5 rounded-md border border-trace/40 bg-trace/10 px-2.5 py-1 font-mono text-[11px] font-bold text-trace hover:bg-trace/20 transition"
          >
            <Layers size={12} />
            <span>Case Study & Diagrams</span>
          </button>
        )}
      </div>

      <h3 className="mt-2 text-xl font-bold text-white tracking-tight">{p.title}</h3>

      <div className="mt-2.5 flex flex-wrap gap-1.5">
        {p.tech.map((t) => (
          <span key={t} className="rounded border border-edge bg-die px-2 py-0.5 font-mono text-xs text-trace">
            {t}
          </span>
        ))}
      </div>

      <div role="tablist" className="mt-4 flex flex-wrap gap-x-4 gap-y-1 border-b border-edge text-sm">
        {TABS.map(([k, l]) => (
          <button
            key={k}
            role="tab"
            aria-selected={tab === k}
            onClick={() => setTab(k)}
            className={`-mb-px border-b-2 pb-2 font-medium transition ${
              tab === k ? "border-trace text-trace" : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            {l}
          </button>
        ))}
      </div>

      <div role="tabpanel" className="mt-4 flex-1 text-sm leading-relaxed">
        {tab === "Overview" && <p className="text-slate-300">{p.overview}</p>}
        {tab === "specs" && (
          <ul className="list-disc space-y-1 pl-5 text-slate-300">
            {p.specs.map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ul>
        )}
        {tab === "strategy" && (
          <ul className="list-disc space-y-1 pl-5 text-slate-300">
            {p.strategy.map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ul>
        )}
        {tab === "results" && (
          <div className="space-y-3">
            {p.results.map((r) => (
              <div key={r.label}>
                <div className="flex justify-between">
                  <span className="text-slate-400">{r.label}</span>
                  <span className="font-mono font-bold text-pass">{r.value}</span>
                </div>
                {r.pct !== undefined && (
                  <div className="mt-1 h-1.5 rounded bg-edge overflow-hidden">
                    <div className="h-full rounded bg-pass transition-all duration-1000" style={{ width: `${r.pct}%` }} />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="mt-4 pt-3 border-t border-edge/60 flex items-center justify-between">
        {p.code ? (
          <button
            onClick={() => setCode(!code)}
            aria-expanded={code}
            className="font-mono text-xs text-clock hover:underline flex items-center gap-1"
          >
            <span>{code ? "$ close" : "$ cat"}</span> {p.id}.{p.code.lang === "c" ? "c" : "sv"}
          </button>
        ) : (
          <span className="font-mono text-xs text-slate-500">ASIC & FPGA Flow</span>
        )}

        {onOpenCaseStudy && (
          <button
            onClick={() => onOpenCaseStudy(p)}
            className="font-mono text-xs text-trace hover:underline inline-flex items-center gap-1 font-semibold"
          >
            Full Architecture <ArrowRight size={12} />
          </button>
        )}
      </div>

      {code && p.code && (
        <pre className="mt-3 overflow-x-auto rounded border border-edge bg-die p-3 font-mono text-xs text-slate-300">
          <code>{p.code.src}</code>
        </pre>
      )}
    </article>
  );
}
