"use client";
import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { Github, Linkedin, Mail, ArrowRight, Download } from "lucide-react";
import { profile, metrics } from "@/data/portfolioData";

function Ring({ value, suffix, label, color, note }: (typeof metrics)[number]) {
  const [p, setP] = useState(0);
  useEffect(() => { const t = setTimeout(() => setP(1), 300); return () => clearTimeout(t); }, []);
  const r = 34, c = 2 * Math.PI * r, shown = Math.min(value, 100) / 100;
  return (
    <div className="flex items-center gap-3 rounded-lg border border-edge bg-card p-3 shadow-sm hover:border-slate-700 transition">
      <svg width="80" height="80" viewBox="0 0 80 80" aria-hidden className="shrink-0">
        <circle cx="40" cy="40" r={r} fill="none" stroke="#1E293B" strokeWidth="6" />
        <circle cx="40" cy="40" r={r} fill="none" stroke={color} strokeWidth="6" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - shown * p)} transform="rotate(-90 40 40)"
          style={{ transition: "stroke-dashoffset 1.6s ease-out" }} />
      </svg>
      <div>
        <div className="font-mono text-xl font-bold" style={{ color }}>{value}{suffix}</div>
        <div className="text-xs text-slate-300 font-medium">{label}</div>
        {note && <div className="text-[10px] text-slate-500 font-mono mt-0.5">{note}</div>}
      </div>
    </div>
  );
}

export default function Hero() {
  const ref = useRef<HTMLElement>(null);
  const onMove = (e: React.MouseEvent) => {
    const el = ref.current; if (!el) return; const b = el.getBoundingClientRect();
    el.style.setProperty("--x", `${e.clientX - b.left}px`); el.style.setProperty("--y", `${e.clientY - b.top}px`);
  };

  return (
    <section id="top" ref={ref} onMouseMove={onMove} className="relative overflow-hidden border-b border-edge">
      <div className="absolute inset-0 opacity-60" style={{ backgroundImage: "linear-gradient(#1E293B55 1px,transparent 1px),linear-gradient(90deg,#1E293B55 1px,transparent 1px)", backgroundSize: "40px 40px" }} />
      <div className="absolute inset-0" style={{ background: "radial-gradient(420px circle at var(--x,50%) var(--y,30%), rgba(0,242,254,.15), transparent 70%)" }} />
      
      <div className="relative mx-auto max-w-6xl px-5 py-16 md:py-24">
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-12">
          
          {/* Left Column: Bio, Name & Actions */}
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 rounded-full border border-edge bg-die/90 px-3.5 py-1.5 font-mono text-xs text-pass shadow-sm">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-pass opacity-75"></span>
                <span className="relative inline-flex h-2 w-2 rounded-full bg-pass"></span>
              </span>
              <span>abhijit@silicon-host:~$</span>
              <span className="text-trace">./whoami</span>
              <span className="clk text-trace">▌</span>
            </div>

            <div className="mt-4">
              <span className="font-mono text-xs font-semibold uppercase tracking-widest text-clock">
                Silicon Portfolio
              </span>
              <h1 className="mt-1 text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
                {profile.name}
              </h1>
              <div className="mt-2 text-xl font-bold bg-gradient-to-r from-trace via-teal-200 to-pass bg-clip-text text-transparent sm:text-2xl">
                {profile.role}
              </div>
            </div>

            <p className="mt-5 text-lg font-medium leading-snug text-slate-200">
              &ldquo;{profile.headline}&rdquo;
            </p>
            <p className="mt-2 max-w-xl text-base leading-relaxed text-slate-400">
              {profile.summary}
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a href="#projects" className="inline-flex items-center gap-2 rounded bg-trace px-5 py-2.5 font-semibold text-die shadow-lg shadow-trace/20 transition hover:brightness-110">
                View projects <ArrowRight size={16} />
              </a>
              <a href="/Abhijit_Karale_RTL_DV_Resume.pdf" download className="inline-flex items-center gap-2 rounded border border-edge bg-card/60 px-4 py-2.5 text-white transition hover:border-trace hover:text-trace">
                <Download size={16} className="text-trace" /> Resume (RTL)
              </a>
              <a href={`mailto:${profile.email}`} className="inline-flex items-center gap-2 rounded border border-edge bg-card/60 px-4 py-2.5 text-white transition hover:border-trace">
                <Mail size={16} /> Email me
              </a>
              <a aria-label="GitHub" href={profile.github} target="_blank" rel="noreferrer" className="rounded border border-edge bg-card/60 p-2.5 text-slate-300 transition hover:border-trace hover:text-trace">
                <Github size={20} />
              </a>
              <a aria-label="LinkedIn" href={profile.linkedin} target="_blank" rel="noreferrer" className="rounded border border-edge bg-card/60 p-2.5 text-slate-300 transition hover:border-trace hover:text-trace">
                <Linkedin size={20} />
              </a>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-4 font-mono text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="text-trace">📍</span> {profile.location}
              </span>
              <span className="text-slate-600">•</span>
              <span className="flex items-center gap-1.5 text-pass">
                <span className="h-1.5 w-1.5 rounded-full bg-pass" /> Available for RTL & Verification Roles
              </span>
            </div>
          </div>

          {/* Right Column: Silicon Profile Photo Frame */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-sm sm:max-w-md">
              {/* Ambient Glow Backdrop */}
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-tr from-trace/30 via-bus/20 to-pass/30 blur-2xl opacity-70" />

              {/* Silicon Package Frame */}
              <div className="relative overflow-hidden rounded-2xl border border-edge bg-card p-3.5 shadow-2xl backdrop-blur-sm">
                {/* Silicon Header Bar */}
                <div className="mb-3 flex items-center justify-between border-b border-edge/80 pb-2.5 px-1 font-mono text-[11px] text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="relative flex h-2 w-2">
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-pass opacity-75"></span>
                      <span className="relative inline-flex h-2 w-2 rounded-full bg-pass"></span>
                    </span>
                    <span className="font-semibold text-slate-200">IC_DIE // RV32I_CORE</span>
                  </div>
                  <span className="font-mono font-semibold text-trace">TAPE-OUT_READY</span>
                </div>

                {/* Photo Container */}
                <div className="group relative aspect-[3/4] w-full overflow-hidden rounded-xl border border-edge bg-die">
                  <Image
                    src="/profile.jpg"
                    alt="Abhijit Karale - RTL & Verification Engineer"
                    fill
                    priority
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 45vw, 420px"
                    className="object-cover object-top transition duration-700 ease-out group-hover:scale-105"
                  />

                  {/* Corner reticle tech markers */}
                  <div className="pointer-events-none absolute top-2.5 left-2.5 font-mono text-[10px] tracking-tighter text-trace/80">
                    + DIE_X0Y0
                  </div>
                  <div className="pointer-events-none absolute top-2.5 right-2.5 font-mono text-[10px] tracking-tighter text-trace/80">
                    [UVM_PASS]
                  </div>

                  {/* Floating Glass Badge */}
                  <div className="absolute inset-x-2.5 bottom-2.5 rounded-xl border border-edge/80 bg-die/85 p-3 backdrop-blur-md shadow-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-bold text-white tracking-wide">{profile.name}</div>
                        <div className="font-mono text-[11px] text-trace">RTL & Formal Verification</div>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="rounded border border-pass/40 bg-pass/20 px-2 py-0.5 font-mono text-[10px] font-bold text-pass">
                          100% PROVEN
                        </span>
                        <span className="mt-0.5 font-mono text-[9px] text-slate-400">JasperGold • SVA</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* IC Specs Footer */}
                <div className="mt-3 flex items-center justify-between px-1 font-mono text-[10px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-trace" /> Cadence Xcelium
                  </span>
                  <span className="text-slate-600">|</span>
                  <span>STM32 • nRF52</span>
                  <span className="text-slate-600">|</span>
                  <span className="text-clock">Gray CDC FIFOs</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Metrics Row */}
        <div className="mt-14 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {metrics.map((m) => <Ring key={m.label} {...m} />)}
        </div>
      </div>
    </section>
  );
}
