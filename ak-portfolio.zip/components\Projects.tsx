"use client";
import { useState } from "react";
import { CATEGORIES, projects, Project } from "@/data/portfolioData";
import ProjectCard from "./ProjectCard";
import CaseStudyModal from "./CaseStudyModal";

export default function Projects() {
  const [f, setF] = useState<string>("All Projects");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const list = projects.filter((p) => f === "All Projects" || p.category === f);

  return (
    <section id="projects" className="mx-auto max-w-6xl px-5 py-20">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div>
          <span className="font-mono text-xs font-semibold uppercase tracking-widest text-trace">
            Silicon & Firmware Engineering
          </span>
          <h2 className="mt-1 text-3xl sm:text-4xl font-bold text-white tracking-tight">Technical Projects</h2>
          <p className="mt-2 text-slate-400 max-w-xl text-sm leading-relaxed">
            Click &ldquo;Case Study &amp; Diagrams&rdquo; on any project to explore detailed microarchitecture schematics, UVM testbench architectures, and formal verification proofs.
          </p>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-2" role="tablist" aria-label="Filter projects">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            role="tab"
            aria-selected={f === c}
            onClick={() => setF(c)}
            className={`rounded-lg border px-3.5 py-1.5 text-xs font-mono font-medium transition ${
              f === c
                ? "border-trace bg-trace/15 text-trace shadow-sm font-bold"
                : "border-edge bg-card/60 text-slate-400 hover:text-white hover:border-slate-600"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        {list.map((p) => (
          <ProjectCard key={p.id} p={p} onOpenCaseStudy={(proj) => setSelectedProject(proj)} />
        ))}
      </div>

      {/* Accessible Case Study Modal */}
      <CaseStudyModal
        project={selectedProject}
        isOpen={!!selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
}
