"use client";
import React, { useState, useEffect, useRef } from "react";
import Image from "next/image";
import { Terminal, Download, Menu, X, ChevronDown, FileText, CheckCircle2 } from "lucide-react";
import { profile } from "@/data/portfolioData";

const links = [
  ["about", "Advantage"],
  ["projects", "Projects"],
  ["skills", "Skills & Regs"],
  ["career", "Career"],
  ["certs", "Certs"],
  ["contact", "Contact"],
];

interface NavbarProps {
  onOpenTerminal?: () => void;
}

export default function Navbar({ onOpenTerminal }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [resumeDropdownOpen, setResumeDropdownOpen] = useState(false);
  const resumeMenuRef = useRef<HTMLDivElement | null>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (resumeMenuRef.current && !resumeMenuRef.current.contains(e.target as Node)) {
        setResumeDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleOutsideClick);
    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-edge bg-die/85 backdrop-blur-md">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3" aria-label="Primary">
        {/* Brand / Profile Avatar */}
        <a href="#top" className="group flex items-center gap-3">
          <div className="relative h-9 w-9 overflow-hidden rounded-full border-2 border-trace/40 ring-2 ring-trace/20 transition group-hover:border-trace group-hover:ring-trace/40">
            <Image
              src="/profile.jpg"
              alt={profile.name}
              width={36}
              height={36}
              className="h-full w-full object-cover object-top"
              priority
            />
          </div>
          <div className="flex flex-col">
            <span className="font-mono text-sm font-bold tracking-tight text-white transition group-hover:text-trace">
              {profile.name}
            </span>
            <span className="font-mono text-[10px] text-slate-400">
              RTL &amp; Verification Engineer
            </span>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <ul className="hidden lg:flex items-center gap-6 text-sm">
          {links.map(([id, l]) => (
            <li key={id}>
              <a className="text-slate-300 font-medium transition hover:text-trace" href={`#${id}`}>
                {l}
              </a>
            </li>
          ))}
        </ul>

        {/* Right Action Buttons */}
        <div className="hidden sm:flex items-center gap-3">
          {/* Download Resume Dropdown */}
          <div className="relative" ref={resumeMenuRef}>
            <button
              onClick={() => setResumeDropdownOpen(!resumeDropdownOpen)}
              className="flex items-center gap-1.5 rounded-lg border border-edge bg-card px-3 py-1.5 font-mono text-xs text-slate-200 transition hover:border-trace hover:text-trace"
              aria-expanded={resumeDropdownOpen}
              aria-haspopup="true"
            >
              <Download size={13} className="text-trace" />
              <span>Resume</span>
              <ChevronDown size={13} className={`transition ${resumeDropdownOpen ? "rotate-180" : ""}`} />
            </button>

            {resumeDropdownOpen && (
              <div className="absolute right-0 mt-2 w-64 rounded-xl border border-edge bg-die p-2 shadow-2xl z-50 font-mono text-xs space-y-1">
                <div className="px-3 py-1.5 text-[10px] text-slate-500 uppercase tracking-wider font-bold">
                  Select Specialized Resume:
                </div>
                <a
                  href="/Abhijit_Karale_RTL_DV_Resume.pdf"
                  download
                  onClick={() => setResumeDropdownOpen(false)}
                  className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-slate-200 hover:bg-card hover:text-trace transition"
                >
                  <FileText size={15} className="text-trace shrink-0" />
                  <div>
                    <div className="font-semibold text-white">RTL &amp; Verification (PDF)</div>
                    <div className="text-[10px] text-slate-400">UVM, SystemVerilog, Formal</div>
                  </div>
                </a>
                <a
                  href="/Abhijit_Karale_Embedded_Resume.pdf"
                  download
                  onClick={() => setResumeDropdownOpen(false)}
                  className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-slate-200 hover:bg-card hover:text-pass transition"
                >
                  <FileText size={15} className="text-pass shrink-0" />
                  <div>
                    <div className="font-semibold text-white">Embedded Systems (PDF)</div>
                    <div className="text-[10px] text-slate-400">STM32, FreeRTOS, Bring-Up</div>
                  </div>
                </a>
              </div>
            )}
          </div>

          {/* Terminal Toggle Button */}
          <button
            onClick={onOpenTerminal}
            aria-label="Open silicon terminal drawer"
            className="flex items-center gap-2 rounded-lg border border-edge bg-card px-3 py-1.5 font-mono text-xs text-trace transition hover:border-trace hover:bg-trace/10"
          >
            <Terminal size={14} />
            <span>terminal</span>
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex items-center gap-2 lg:hidden">
          <button
            onClick={onOpenTerminal}
            aria-label="Open silicon terminal drawer"
            className="rounded border border-edge bg-card p-2 text-trace hover:border-trace transition sm:hidden"
          >
            <Terminal size={16} />
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? "Close navigation menu" : "Open navigation menu"}
            className="rounded-lg border border-edge bg-card p-2 text-slate-300 hover:text-white hover:border-trace transition"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {/* Mobile Drawer / Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-edge bg-die/95 px-5 py-4 font-mono text-sm space-y-4 shadow-xl">
          <ul className="space-y-2">
            {links.map(([id, l]) => (
              <li key={id}>
                <a
                  className="block rounded-lg px-3 py-2 text-slate-300 hover:bg-card hover:text-trace transition"
                  href={`#${id}`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {l}
                </a>
              </li>
            ))}
          </ul>

          <div className="pt-3 border-t border-edge/80 space-y-2">
            <div className="text-[11px] text-slate-500 uppercase font-semibold">Download Specialized Resumes:</div>
            <div className="grid grid-cols-1 gap-2">
              <a
                href="/Abhijit_Karale_RTL_DV_Resume.pdf"
                download
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-2 rounded-lg border border-edge bg-card p-2.5 text-xs text-trace hover:border-trace transition"
              >
                <Download size={14} />
                <span>RTL &amp; DV Resume (PDF)</span>
              </a>
              <a
                href="/Abhijit_Karale_Embedded_Resume.pdf"
                download
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-2 rounded-lg border border-edge bg-card p-2.5 text-xs text-pass hover:border-pass transition"
              >
                <Download size={14} />
                <span>Embedded Systems Resume (PDF)</span>
              </a>
            </div>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenTerminal?.();
              }}
              className="w-full flex items-center justify-center gap-2 rounded-lg border border-trace bg-trace/10 py-2.5 text-xs text-trace font-bold hover:bg-trace/20 transition"
            >
              <Terminal size={14} />
              <span>Open Interactive Terminal</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
