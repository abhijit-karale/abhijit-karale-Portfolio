"use client";
import { useState } from "react";
import { Cpu, CircuitBoard, BadgeCheck, Copy, Briefcase, GraduationCap, Award, MapPin, Calendar, FileText, CheckCircle2 } from "lucide-react";
import { timeline, certifications, profile, JourneyItem } from "@/data/portfolioData";

export function DualAdvantage() {
  const [side, setSide] = useState<"hw" | "rtl" | null>(null);
  const card = (k: "hw" | "rtl", icon: React.ReactNode, title: string, color: string, body: string, pts: string[]) => (
    <button onClick={() => setSide(side === k ? null : k)} aria-pressed={side === k}
      className={`rounded-lg border bg-card p-6 text-left transition ${side === k ? "" : "border-edge"}`} style={side === k ? { borderColor: color } : {}}>
      <div style={{ color }}>{icon}</div><h3 className="mt-3 text-xl font-semibold text-white">{title}</h3>
      <p className="mt-2 text-sm text-slate-400">{body}</p>
      {side === k && <ul className="mt-4 list-disc space-y-1 pl-5 text-sm">{pts.map((p) => <li key={p}>{p}</li>)}</ul>}
    </button>);
  return (
    <section id="about" className="mx-auto max-w-6xl px-5 py-20">
      <h2 className="text-3xl font-bold text-white">From the bench to the testbench</h2>
      <p className="mt-3 max-w-2xl text-slate-400">I know how timing misbehaves on a real board, and I use that when I write assertions and coverage. Tap a card to expand it.</p>
      <div className="mt-8 grid gap-5 md:grid-cols-2">
        {card("hw", <CircuitBoard />, "Physical hardware & firmware", "#F59E0B", "2+ years of firmware and bring-up on STM32 and nRF52.", ["UART, SPI, I2C, ADC, PWM drivers on FreeRTOS", "PCB debugging and schematic-to-board correlation", "Oscilloscope-led root-cause analysis", "Low-power BLE: System ON / OFF"])}
        {card("rtl", <Cpu />, "RTL microarchitecture & formal verification", "#00F2FE", "Pipelined cores, protocol blocks and proofs.", ["5-stage RV32I with 95%+ UVM functional coverage", "SVA and JasperGold exhaustive proofs", "CDC-safe FIFOs, APB and UART blocks", "Synthesis to timing closure on an 8-bit RISC"])}
      </div>
    </section>);
}

export function Timeline() {
  const [filter, setFilter] = useState<"all" | "experience" | "education" | "leadership">("all");

  const filteredItems = timeline.filter((t) => {
    if (filter === "all") return true;
    return t.category === filter;
  });

  const getIcon = (item: JourneyItem) => {
    if (item.category === "education") return <GraduationCap size={16} className="text-bus" />;
    if (item.category === "leadership") return <Award size={16} className="text-clock" />;
    return <Briefcase size={16} className="text-trace" />;
  };

  const getTypeBadgeClass = (type: JourneyItem["type"]) => {
    switch (type) {
      case "Internship":
        return "border-trace/40 bg-trace/10 text-trace";
      case "Full-time":
        return "border-pass/40 bg-pass/10 text-pass";
      case "Degree":
      case "Diploma":
        return "border-bus/40 bg-bus/10 text-bus";
      case "Leadership":
        return "border-clock/40 bg-clock/10 text-clock";
      default:
        return "border-edge text-slate-400";
    }
  };

  const getNodeColor = (item: JourneyItem) => {
    if (item.category === "education") return "#8B5CF6";
    if (item.category === "leadership") return "#F59E0B";
    return "#00F2FE";
  };

  return (
    <section id="career" className="mx-auto max-w-5xl px-5 py-20">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <span className="font-mono text-xs uppercase tracking-widest text-trace font-semibold">
            Track Record & Academics
          </span>
          <h2 className="mt-1 text-3xl sm:text-4xl font-bold text-white">Career & Education Journey</h2>
          <p className="mt-2 text-slate-400 max-w-xl text-sm leading-relaxed">
            From hands-on embedded firmware bring-up on physical boards to advanced RTL design and UVM verification.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap gap-1.5 rounded-lg border border-edge bg-die p-1 self-start md:self-auto font-mono text-xs">
          {[
            { key: "all", label: "All Journey", count: timeline.length },
            { key: "experience", label: "Experience", count: timeline.filter((i) => i.category === "experience").length },
            { key: "education", label: "Education", count: timeline.filter((i) => i.category === "education").length },
            { key: "leadership", label: "Leadership", count: timeline.filter((i) => i.category === "leadership").length },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key as typeof filter)}
              className={`rounded px-3 py-1.5 transition ${
                filter === tab.key
                  ? "bg-trace text-die font-bold shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {tab.label} <span className="opacity-70">({tab.count})</span>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-12 relative border-l-2 border-edge pl-6 sm:pl-8 space-y-10">
        {filteredItems.map((t) => (
          <div key={t.id} className="relative group">
            {/* Timeline Node Icon */}
            <div
              className="absolute -left-[35px] sm:-left-[43px] top-1.5 flex h-7 w-7 sm:h-8 sm:w-8 items-center justify-center rounded-full border-2 border-die bg-card shadow-md transition group-hover:scale-110"
              style={{ borderColor: getNodeColor(t) }}
            >
              {getIcon(t)}
            </div>

            {/* Journey Card */}
            <div className="rounded-xl border border-edge bg-card p-5 sm:p-6 transition hover:border-slate-700 shadow-sm">
              {/* Header: Title, Org & Type Badges */}
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2.5">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                      {t.title}
                    </h3>
                    <span className={`rounded border px-2 py-0.5 font-mono text-xs font-semibold ${getTypeBadgeClass(t.type)}`}>
                      {t.type}
                    </span>
                    {t.isCurrent && (
                      <span className="inline-flex items-center gap-1.5 rounded-full border border-pass/40 bg-pass/20 px-2.5 py-0.5 font-mono text-[11px] font-bold text-pass">
                        <span className="h-1.5 w-1.5 rounded-full bg-pass animate-ping" /> Present
                      </span>
                    )}
                  </div>
                  <div className="mt-1 text-base font-medium text-slate-200">
                    {t.org}
                  </div>
                </div>

                {t.grade && (
                  <div className="shrink-0">
                    <span className="inline-flex items-center gap-1.5 rounded border border-pass/40 bg-pass/10 px-2.5 py-1 font-mono text-xs font-bold text-pass">
                      <CheckCircle2 size={13} /> {t.grade}
                    </span>
                  </div>
                )}
              </div>

              {/* Meta: Period, Duration, Location */}
              <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 font-mono text-xs text-slate-400 border-b border-edge/60 pb-3">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Calendar size={13} className="text-trace" />
                  {t.when} {t.duration ? `· ${t.duration}` : ""}
                </span>
                <span className="text-slate-600">•</span>
                <span className="flex items-center gap-1.5">
                  <MapPin size={13} className="text-slate-400" />
                  {t.location} {t.mode ? `(${t.mode})` : ""}
                </span>
              </div>

              {/* Achievements / Points */}
              <ul className="mt-4 space-y-2 text-sm text-slate-300">
                {t.points.map((p) => (
                  <li key={p} className="flex items-start gap-2 leading-relaxed">
                    <span className="text-trace mt-1">▸</span>
                    <span>{p}</span>
                  </li>
                ))}
              </ul>

              {/* Skill Tags */}
              {t.skills && t.skills.length > 0 && (
                <div className="mt-4 flex flex-wrap items-center gap-1.5 pt-2">
                  {t.skills.map((s) => (
                    <span
                      key={s}
                      className="rounded border border-edge/80 bg-die/60 px-2.5 py-0.5 font-mono text-[11px] text-slate-300 hover:border-trace/40 transition"
                    >
                      #{s}
                    </span>
                  ))}
                </div>
              )}

              {/* Attached Credential / Document */}
              {t.credential && (
                <div className="mt-4 inline-flex items-center gap-2 rounded-lg border border-edge bg-die px-3 py-1.5 font-mono text-xs text-trace">
                  <FileText size={14} />
                  <span>{t.credential}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function Certs() {
  return (
    <section id="certs" className="border-y border-edge bg-substrate">
      <div className="mx-auto max-w-6xl px-5 py-20">
        <h2 className="text-3xl font-bold text-white">Certifications</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {certifications.map((c) => (
            <div key={c.name} className="flex gap-3 rounded-lg border border-edge bg-card p-4">
              <BadgeCheck className="mt-0.5 shrink-0 text-pass" size={20} />
              <div><div className="font-medium text-white">{c.name}</div><div className="text-sm text-slate-400">{c.issuer}</div>{c.note && <div className="mt-1 text-xs text-clock">{c.note}</div>}</div>
            </div>))}
        </div>
      </div>
    </section>);
}

export function ContactTerminal() {
  const [copied, setCopied] = useState(false);
  const json = `{\n  "name": "${profile.name}",\n  "email": "${profile.email}",\n  "phone": "${profile.phone}",\n  "location": "${profile.location}",\n  "github": "${profile.github}",\n  "linkedin": "${profile.linkedin}"\n}`;
  return (
    <section id="contact" className="mx-auto max-w-3xl px-5 py-20">
      <h2 className="text-3xl font-bold text-white">Contact</h2>
      <div className="mt-6 overflow-hidden rounded-lg border border-edge bg-die font-mono text-sm">
        <div className="flex items-center justify-between border-b border-edge bg-card px-4 py-2 text-xs text-slate-400"><span>abhijit@silicon-host</span>
          <button onClick={() => { navigator.clipboard?.writeText(profile.email); setCopied(true); setTimeout(() => setCopied(false), 1500); }} className="flex items-center gap-1 hover:text-trace"><Copy size={12} />{copied ? "copied" : "copy email"}</button></div>
        <div className="p-4 space-y-2">
          <p className="text-pass">abhijit@silicon-host:~$ cat contact_info.json</p>
          <pre className="mt-2 overflow-x-auto text-slate-300">{json}</pre>
          <div className="mt-4 pt-3 border-t border-edge/60 flex flex-wrap items-center justify-between gap-3 text-xs">
            <p className="text-pass">abhijit@silicon-host:~$ <a className="text-trace underline hover:brightness-125" href={`mailto:${profile.email}`}>./send_mail</a> <span className="clk">▌</span></p>
            <div className="flex items-center gap-3">
              <a href="/Abhijit_Karale_RTL_DV_Resume.pdf" download className="text-clock hover:underline flex items-center gap-1 font-mono">
                [download_rtl_resume.pdf]
              </a>
              <a href="/Abhijit_Karale_Embedded_Resume.pdf" download className="text-pass hover:underline flex items-center gap-1 font-mono">
                [download_embedded_resume.pdf]
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>);
}
