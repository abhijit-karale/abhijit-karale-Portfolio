"use client";
import React, { useState } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Projects from "@/components/Projects";
import SkillGrid from "@/components/SkillGrid";
import { DualAdvantage, Timeline, Certs, ContactTerminal } from "@/components/Sections";
import WaveformDivider from "@/components/WaveformDivider";
import CanvasBackground from "@/components/CanvasBackground";
import TerminalDrawer from "@/components/TerminalDrawer";

export default function Page() {
  const [terminalOpen, setTerminalOpen] = useState(false);

  return (
    <>
      {/* Animated Wafer/PCB-Trace Canvas Background with Cursor Glow */}
      <CanvasBackground />

      {/* Top Navbar with Mobile Hamburger & Dual Resume Downloads */}
      <Navbar onOpenTerminal={() => setTerminalOpen(true)} />

      <main className="relative z-10">
        {/* Hero Section */}
        <Hero />

        {/* Waveform Divider 1: System Clock Pulses */}
        <WaveformDivider variant="clock" label="SYS_CLK_100MHz // DIGITAL_LOGIC_POSEDGE" />

        {/* Dual Advantage: Physical HW Bring-Up <-> RTL Verification */}
        <DualAdvantage />

        {/* Waveform Divider 2: AMBA APB Bus Transactions */}
        <WaveformDivider variant="bus" label="AMBA_APB_INTERCONNECT // 32-BIT_BUS_TRANSFERS" />

        {/* Technical Projects with Inline SVG Case Study Modals */}
        <Projects />

        {/* Waveform Divider 3: FSM Transitions */}
        <WaveformDivider variant="fsm" label="CDC_GRAY_SYNC // METASTABILITY_IMMUNE_FLOPS" />

        {/* Skill Chips with Proficiency Levels & Register-Map Table View */}
        <SkillGrid />

        {/* Waveform Divider 4: Analog to Digital SPICE Signal */}
        <WaveformDivider variant="analog" label="SPICE_ANALOG_AFE // MOSFET_CHARACTERIZATION_FLOW" />

        {/* Professional Career & Education Journey from LinkedIn */}
        <Timeline />

        {/* Waveform Divider 5: Verification Sign-Off */}
        <WaveformDivider variant="clock" label="TAPE_OUT_READY // 100%_JASPERGOLD_PROOFS" />

        {/* Professional Certifications */}
        <Certs />

        {/* Contact Terminal */}
        <ContactTerminal />
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-edge bg-die/90 py-8 text-center font-mono text-xs text-slate-500">
        <div className="mx-auto max-w-6xl px-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-pass" />
            <span>&copy; 2026 Abhijit Karale &bull; Ahmedabad &amp; Bengaluru, India</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => setTerminalOpen(true)}
              className="hover:text-trace transition flex items-center gap-1"
            >
              <span>$ terminal</span>
            </button>
            <span>&bull;</span>
            <a href="#top" className="hover:text-trace transition">
              Back to Top &uarr;
            </a>
          </div>
        </div>
      </footer>

      {/* Working Silicon Terminal Drawer */}
      <TerminalDrawer
        isOpen={terminalOpen}
        onClose={() => setTerminalOpen(false)}
      />
    </>
  );
}
