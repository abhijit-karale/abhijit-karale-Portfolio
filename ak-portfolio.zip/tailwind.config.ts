import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: { colors: {
    die: "#0A0D14", substrate: "#0F172A", card: "#131B2E", edge: "#1E293B",
    trace: "#00F2FE", pass: "#10B981", clock: "#F59E0B", bus: "#8B5CF6" },
    fontFamily: { sans: ["var(--font-sans)", "system-ui", "sans-serif"], mono: ["var(--font-mono)", "ui-monospace", "monospace"] } } },
  plugins: [],
};
export default config;
