"use client";
import React, { useState } from "react";
import { Table, LayoutGrid, Search, ShieldCheck, CheckCircle2, Cpu } from "lucide-react";
import { skills, registerMap, Proficiency } from "@/data/portfolioData";

export default function SkillGrid() {
  const [viewMode, setViewMode] = useState<"chips" | "registers">("chips");
  const [filterQuery, setFilterQuery] = useState("");
  const [activeSubsystem, setActiveSubsystem] = useState<string>("ALL");

  const getProficiencyBadge = (level: Proficiency) => {
    switch (level) {
      case "Strong":
        return "bg-trace/15 text-trace border-trace/30";
      case "Working":
        return "bg-pass/15 text-pass border-pass/30";
      case "Familiar":
        return "bg-clock/15 text-clock border-clock/30";
    }
  };

  const subsystems = ["ALL", ...Array.from(new Set(registerMap.map((r) => r.subsystem)))];

  const filteredRegisters = registerMap.filter((r) => {
    const matchesSubsystem = activeSubsystem === "ALL" || r.subsystem === activeSubsystem;
    const matchesQuery =
      filterQuery === "" ||
      r.registerName.toLowerCase().includes(filterQuery.toLowerCase()) ||
      r.field.toLowerCase().includes(filterQuery.toLowerCase()) ||
      r.description.toLowerCase().includes(filterQuery.toLowerCase()) ||
      r.offset.toLowerCase().includes(filterQuery.toLowerCase());
    return matchesSubsystem && matchesQuery;
  });

  return (
    <section id="skills" className="border-y border-edge bg-substrate py-20">
      <div className="mx-auto max-w-6xl px-5">
        {/* Header with Title and Mode Toggle */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 border-b border-edge/80 pb-6">
          <div>
            <span className="font-mono text-xs font-semibold uppercase tracking-widest text-trace">
              Silicon & Firmware Competencies
            </span>
            <h2 className="mt-1 text-3xl sm:text-4xl font-bold text-white tracking-tight">
              Technical Skills &amp; Register Map
            </h2>
            <p className="mt-2 text-slate-400 max-w-2xl text-sm leading-relaxed">
              Explore skills via categorized silicon subsystems or inspect the memory-mapped register table specifying hardware control registers and verified methodology vectors.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            {/* View Mode Toggle */}
            <div className="inline-flex rounded-lg border border-edge bg-die p-1 font-mono text-xs">
              <button
                onClick={() => setViewMode("chips")}
                className={`flex items-center gap-2 rounded px-3 py-1.5 transition ${
                  viewMode === "chips"
                    ? "bg-trace text-die font-bold shadow-sm"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <LayoutGrid size={14} />
                <span>Chips View</span>
              </button>
              <button
                onClick={() => setViewMode("registers")}
                className={`flex items-center gap-2 rounded px-3 py-1.5 transition ${
                  viewMode === "registers"
                    ? "bg-trace text-die font-bold shadow-sm"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Table size={14} />
                <span>Register-Map View</span>
              </button>
            </div>
          </div>
        </div>

        {/* Proficiency Legend Bar */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-4 font-mono text-xs text-slate-400">
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-slate-500">Proficiency Levels:</span>
            <span className="inline-flex items-center gap-1.5 rounded border border-trace/30 bg-trace/10 px-2 py-0.5 text-trace font-semibold">
              <span className="h-1.5 w-1.5 rounded-full bg-trace" /> Strong (Production / Tape-out Ready)
            </span>
            <span className="inline-flex items-center gap-1.5 rounded border border-pass/30 bg-pass/10 px-2 py-0.5 text-pass font-semibold">
              <span className="h-1.5 w-1.5 rounded-full bg-pass" /> Working (Hands-On Implementation)
            </span>
            <span className="inline-flex items-center gap-1.5 rounded border border-clock/30 bg-clock/10 px-2 py-0.5 text-clock font-semibold">
              <span className="h-1.5 w-1.5 rounded-full bg-clock" /> Familiar (Foundations &amp; Academic)
            </span>
          </div>
        </div>

        {/* 1. CHIPS / CATEGORIZED VIEW */}
        {viewMode === "chips" && (
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            {skills.map((s) => (
              <div
                key={s.id}
                className="rounded-xl border border-edge bg-card p-6 transition hover:border-slate-700 shadow-sm"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                    <h3 className="font-bold text-white text-base tracking-tight">{s.title}</h3>
                  </div>
                  <span className="font-mono text-xs font-bold" style={{ color: s.color }}>
                    0x{s.level.toString(16).toUpperCase()} &bull; {s.level}%
                  </span>
                </div>

                <div className="mt-2.5 h-1.5 rounded bg-edge overflow-hidden">
                  <div className="h-full rounded transition-all duration-1000" style={{ width: `${s.level}%`, background: s.color }} />
                </div>

                <div className="mt-5 flex flex-wrap gap-2">
                  {s.items.map((item) => (
                    <div
                      key={item.name}
                      className="group flex items-center gap-1.5 rounded-lg border border-edge/80 bg-die/80 px-2.5 py-1 text-xs font-mono text-slate-200 transition hover:border-trace/60"
                    >
                      <span>{item.name}</span>
                      <span className={`rounded border px-1.5 py-0.2 text-[9px] font-bold uppercase ${getProficiencyBadge(item.level)}`}>
                        {item.level}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 2. REGISTER-MAP STYLE TABLE VIEW */}
        {viewMode === "registers" && (
          <div className="mt-8 space-y-4">
            {/* Filter and Search Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-die p-3 rounded-xl border border-edge">
              {/* Search */}
              <div className="relative flex-1">
                <Search size={14} className="absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search register offset, field, or methodology..."
                  value={filterQuery}
                  onChange={(e) => setFilterQuery(e.target.value)}
                  className="w-full rounded-lg border border-edge bg-card pl-9 pr-4 py-1.5 font-mono text-xs text-white placeholder-slate-500 outline-none focus:border-trace"
                />
              </div>

              {/* Subsystem Filters */}
              <div className="flex flex-wrap gap-1">
                {subsystems.map((sub) => (
                  <button
                    key={sub}
                    onClick={() => setActiveSubsystem(sub)}
                    className={`rounded px-2.5 py-1 font-mono text-[11px] transition ${
                      activeSubsystem === sub
                        ? "bg-trace text-die font-bold"
                        : "text-slate-400 hover:text-white bg-card border border-edge"
                    }`}
                  >
                    {sub}
                  </button>
                ))}
              </div>
            </div>

            {/* Hardware Register Table */}
            <div className="overflow-x-auto rounded-xl border border-edge bg-die shadow-inner">
              <table className="w-full text-left font-mono text-xs">
                <thead className="border-b border-edge bg-card/80 text-slate-400">
                  <tr>
                    <th className="py-3 px-4 font-semibold">OFFSET</th>
                    <th className="py-3 px-4 font-semibold">REGISTER NAME</th>
                    <th className="py-3 px-4 font-semibold">BITS</th>
                    <th className="py-3 px-4 font-semibold">FIELD / COMPETENCY</th>
                    <th className="py-3 px-4 font-semibold">TYPE</th>
                    <th className="py-3 px-4 font-semibold">PROFICIENCY</th>
                    <th className="py-3 px-4 font-semibold">SUBSYSTEM</th>
                    <th className="py-3 px-4 font-semibold min-w-[260px]">DESCRIPTION &amp; PROTOCOL SPECS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-edge/60 text-slate-300">
                  {filteredRegisters.map((reg) => (
                    <tr key={reg.offset} className="hover:bg-card/40 transition">
                      <td className="py-3 px-4 font-bold text-trace">{reg.offset}</td>
                      <td className="py-3 px-4 font-bold text-white tracking-wide">{reg.registerName}</td>
                      <td className="py-3 px-4 text-slate-400">{reg.bits}</td>
                      <td className="py-3 px-4 text-slate-200 font-semibold">{reg.field}</td>
                      <td className="py-3 px-4">
                        <span className="rounded bg-edge/80 px-1.5 py-0.5 text-[10px] text-slate-300">
                          {reg.access}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-block rounded border px-2 py-0.5 text-[10px] font-bold uppercase ${getProficiencyBadge(reg.level)}`}>
                          {reg.level}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400">{reg.subsystem}</td>
                      <td className="py-3 px-4 text-slate-300 text-[11px] leading-relaxed">
                        {reg.description}
                      </td>
                    </tr>
                  ))}
                  {filteredRegisters.length === 0 && (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        No registers match your query &quot;{filterQuery}&quot;.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between text-slate-500 font-mono text-[11px] px-2">
              <span>MEMORY MAP BASE: 0x4000_0000 // APB SLAVE PERIPHERAL</span>
              <span>TOTAL REGISTERS: {registerMap.length} (32-BIT ALIGNED)</span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
